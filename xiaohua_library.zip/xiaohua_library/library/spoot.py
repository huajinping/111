from aip import AipFace
import time
import base64,os
from django.conf import settings
APP_ID = '15725387'

API_KEY = 'ZGAZIh4XUzkBwhENnHg298Ox'

SECRET_KEY = 'NzKTgb4slg8Feipc1sdmIDpz358ePw4b'

client = AipFace(APP_ID, API_KEY, SECRET_KEY)

IMAGE_TYPE = 'BASE64'


def test(file1, file2):
    f1 = open(file1, 'rb')

    f2 = open(file2, 'rb')

    # 参数image：图像base64编码 分别base64编码后的2张图片数据

    img1 = base64.b64encode(f1.read())

    img2 = base64.b64encode(f2.read())

    image_1 = str(img1, 'utf-8')

    image_2 = str(img2, 'utf-8')

    ptr = client.match([

        {

            'image': image_1,

            'image_type': 'BASE64',

        },

        {

            'image': image_2,

            'image_type': 'BASE64',

        }

    ])
    try:
        ptr = ptr['result']['score']
    except Exception as e:
        ptr = 0
    return int(ptr)
def main(img_1):
    # img_1 = os.path.join(settings.MEDIA_ROOT,'1.jpg')
    # img_2 = os.path.join(settings.MEDIA_ROOT,'2.png')
    lists = os.listdir(settings.MEDIA_ROOT3)
    print(lists)
    goal =0
    temp =''
    for i in lists:
        t =os.path.join(settings.MEDIA_ROOT3,i)
        try:
            score = test(img_1,t)

        except Exception as e:
            score = 0
        print(score)
        if goal<score:
            goal = score
            if goal >50:
                temp = i
                break
    return temp