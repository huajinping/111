#!/usr/bin/env python
# -*- coding: utf-8 -*-

from django.apps import AppConfig


class libraryConfig(AppConfig):
    name = 'library'
    verbose_name = '借阅管理'
