from django.test import TestCase
import datetime,time
# Create your tests here.
#
# t = time.strftime('%H:%M')
# print(t)
# a = '22:01'
# print(t>a)
# print(t)
# tt = (datetime.datetime.now()+datetime.timedelta(hours=2)).strftime('%H:%M')
# print(tt)
# a =t.split(':')
# import re
# list1 =['7:30','3:24','8:50']
# t = re.compile('^[4-9].*?')
# for i in list1:
#     a = t.findall(i)
#     print(a)
a = time.strftime('%H:%M')
b = "07:30"
print(str(a)>b)
